import * as React from 'react';
import {View, Text} from 'react-native';

export default class AppHeaderGeom extends React.Component{
  render(){
    return(
      <View style={{width:'100%', height:50, backgroundColor:'#ff6d6d', justifyContent:'center'}}>
        <Text style={{alignSelf:'center', fontWeight:'bold', fontSize:20}}>Math Quizzer - Geometry</Text>
      </View>
    );
  }
}