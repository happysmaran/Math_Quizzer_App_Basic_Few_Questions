const geometrydb = {
	"geometry_1": {
		"question": "What is 6² plus 5² equal to?",
		"posAns": ["7", "sq rt 61", "9", "11"],
		"ans": "sq rt 61"
	},
	"geometry_2": {
		"question": "What is the name for the rule a²+b²=c² ?",
		"posAns": ["Pythagorean Theorem", "Hooke's Law", "Newton's law of motion", "No name exists"],
		"ans": "Pythagorean Theorem"
	},
	"geometry_3": {
		"question": "What is a pythagorean triple?",
		"posAns": ["A pythagorean triple is when three numbers, a, b, and c, are perfect squares, such as, 3,4,5 -> 9,16,25.", "It is when all three numbers are factirs of three", "It is when the numbers sum is 3", "There is no thing called a pythagorean triple"],
		"ans": "A pythagorean triple is when three numbers, a, b, and c, are perfect squares, such as, 3,4,5 -> 9,16,25."
	},
	"geometry_4": {
		"question": "What triangle has equal sides and equal angles?",
		"posAns": ["Equilateral", "Isoceles", "Obtuse", "No triangle has such details"],
		"ans": "Equilateral"
	},
	"geometry_5": {
		"question": "The length of a side of a rectangle is 6 cm. What should the length of the other side be so that the perimeter of the rectangle is smaller than the perimeter of a square with a side of 4 cm?",
		"posAns": ["less than 5", "less than 2", "less than 1", "Unable To Answer"],
		"ans": "less than 2"
	},
};
export default geometrydb;