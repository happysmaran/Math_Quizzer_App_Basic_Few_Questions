const algebradb = {
	"algebra_1": {
		"question": "Solve 3x+6=12",
		"posAns": ["x=24", "x=122", "x=7", "x=2"],
		"ans": "x=2"
	},
	"algebra_2": {
		"question": "Solve 4x+2=3x-4",
		"posAns": ["x=5", "x=1", "x=-6", "x=3.14"],
		"ans": "x=-6"
	},
	"algebra_3": {
		"question": "Solve 2x-4=12",
		"posAns": ["x=8", "x=4", "x=3.14", "x=1"],
		"ans": "x=8"
	},
	"algebra_4": {
		"question": "expand (a+b)²",
		"posAns": ["a²+2ab+b²", "a²+b²", "2ab²", "2a²+2b²"],
		"ans": "a²+2ab+b²"
	},
	"algebra_5": {
		"question": "what is 49²-1² ?",
		"posAns": ["2400", "100000", "203153456", "Can't Answer Manually"],
		"ans": "2400"
	},
  "algebra_6": {
		"question": "Solve 5x+3=7x–1",
		"posAns": ["x=1/3", "x=1/2", "x=1", "x=2"],
		"ans": "1"
	},
  "algebra_7": {
		"question": "Solve (5-x)(2x+7)(x-3) <= 0",
		"posAns": ["-3.5 <= x <= 3, x >= 5", "x=24", "54 <= x <= 5", "All Real Numbers"],
		"ans": "-3.5 <= x <= 3, x >= 5"
	},
  "algebra_8": {
		"question": "Solve |4-5x| > 1",
		"posAns": ["x=23", "x=44, x=55", " x>3, x<4", "x<3/5, x>1"],
		"ans": "x<3/5, x>1"
	},
  "algebra_9": {
		"question": "Solve 7x+4>9x-8",
		"posAns": ["x>3", "x<4", "x <= 656", "x<6"],
		"ans": "x<6"
	},
  "algebra_10": {
		"question": "Solve |x+5| > -1",
		"posAns": ["All Real Numbers", "x > -6", "x < 3", "No Solutions"],
		"ans": "All Real Numbers"
	},
  "algebra_11": {
		"question": "Solve |2x+3| < -1",
		"posAns": ["x=2", "x>-1, x<4", "No Solutions", "Answer Undefined"],
		"ans": "No Solutions"
	},
  "algebra_12": {
		"question": "6a(a-1)-2a(3a-2)<6",
		"posAns": ["a<1", "a>-3", "a=1", "All Real Numbers"],
		"ans": "a>-3"
	},
  "algebra_13": {
		"question": "Solve 2-x<0 and x-4<0",
		"posAns": ["2<x<4", "x=2", "No Solutions", "5<x<6"],
		"ans": "2<x<4"
	},
  "algebra_14": {
		"question": "Solve Absolute Value Of 4-6a",
		"posAns": ["a <= 2/3", "a = 34", "a >= 11", "No Real Numbers"],
		"ans": "a <= 2/3"
	},
  "algebra_15": {
		"question": "x(x+2) > 0",
		"posAns": ["x>0, x<-2", "x >= 4", "No Solutions", "All Real Numbers"],
		"ans": "x>0, x<-2"
	},
};
export default algebradb;