import * as React from 'react';
import {TouchableOpacity, View, StyleSheet, Text, Alert} from 'react-native';
import AppHeaderAlg from '../components/AppHeaderAlg';
import algebradb from '../algebraDB';

var randomNumber = Math.floor(Math.random() * 15) + 1;
var disable;

export default class AlgebraScreen extends React.Component{

constructor(){
  super();
  this.state = {
    question : algebradb['algebra_'+randomNumber].question,
    options : algebradb['algebra_'+randomNumber].posAns,
    answer : algebradb['algebra_'+randomNumber].ans,
    userAnswer : ""
  }
}

  componentDidMount(){
    randomNumber = Math.floor(Math.random() * 5) + 1;
    disable=false;
  }

  checkAns(ans){
    var corAns=this.state.answer;
    if(ans !== corAns){
      Alert.alert("Incorrect. Your answer was: "+ans+". Correct answer is: "+corAns)
    }
    else if(ans == corAns){
      Alert.alert("Correct!!")
    }
  }

  render(){
    return(
      <View>
        <AppHeaderAlg />
        <View style={styles.question}>
          <Text style={{fontWeight:'bold'}}>{this.state.question}</Text>
        </View>

        <View>
          {this.state.options.map(item => {
            return (
              <TouchableOpacity
              style={styles.chunkButton} 
              disabled={disable}
              onPress={() => {
                this.setState({
                  userAnswer : item
                })
                this.checkAns(item);
                console.log({item});
                disable=true;
                this.props.navigation.navigate('HomeScreen');
                disable=false;
              }}
              >
              <Text style={styles.displayText}>{item}</Text>
              </TouchableOpacity>
              );
          })}
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  chunkButton:{
    marginTop:20,
    width: '60%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    borderRadius: 10,
    margin: 5,
    backgroundColor: 'lime'
  },
  displayText: {
    textAlign: 'center',
    fontSize: 20,
    color: 'black',
    fontWeight:'bold',
    justifyContent:'center'
  },
  question: {
    marginTop:20,
    textAlign: 'center',
    fontSize: 20,
    backgroundColor: 'cyan',
    borderRadius: 10,
    height: 50,
    justifyContent: 'center',
    alignSelf: 'center',
    width: '100%',
    alignItems:'center'
  }
});
