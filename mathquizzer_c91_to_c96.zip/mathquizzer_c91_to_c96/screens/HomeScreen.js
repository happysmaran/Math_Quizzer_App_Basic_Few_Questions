import * as React from 'react';
import {TouchableOpacity, View, StyleSheet, Text, Image} from 'react-native';
import AppHeader from '../components/AppHeader';

export default class HomeScreen extends React.Component{
  goToScreen = (genre) => {
    this.props.navigation.navigate(genre+'Screen');
  };
  render(){
    return(
      <View>
        <AppHeader />
        <Image
            source={require("../assets/banner.png")}
            style={{ width: 200, height: 200, alignSelf:'center', marginTop:20 }}
          />
        <TouchableOpacity style={styles.genreButton}
          onPress={() => {
            this.goToScreen('Algebra');
          }}
        >
          <Text style={styles.genreText}>Algebra</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.genreButton}
          onPress={() => {
            this.goToScreen('Geometry');
          }}
        >
          <Text style={styles.genreText}>Geometry</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  genreButton : {
    justifyContent:'center', 
    backgroundColor:'#89f963', 
    borderRadius:20,
    marginTop:50,
    height:30,
    width:'75%',
    alignSelf:'center'
  },
  genreText : {
    fontWeight:'bold',
    textAlign:'center'
  }
});