import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import HomeScreen from './screens/HomeScreen';
import AlgebraScreen from './screens/AlgebraScreen';
import GeometryScreen from './screens/GeometryScreen';
import { createSwitchNavigator, createAppContainer } from 'react-navigation';

export default class App extends React.Component {
  render() {
    return (
      <AppContainer/>
    );
  }
}

const AppNavigator = createSwitchNavigator({
  HomeScreen:HomeScreen,
  AlgebraScreen:AlgebraScreen,
  GeometryScreen:GeometryScreen
});

const AppContainer=createAppContainer(AppNavigator);